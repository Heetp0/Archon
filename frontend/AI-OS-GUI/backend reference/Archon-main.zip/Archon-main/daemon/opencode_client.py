import os
import sys
import asyncio
import logging
from typing import AsyncGenerator, Optional

logger = logging.getLogger("opencode_client")

class OpenCodeClient:
    def __init__(self, workspace_root: Optional[str] = None):
        try:
            import config
            self.workspace_root = config.WORKSPACE_ROOT
        except ImportError:
            self.workspace_root = workspace_root or r"D:\The core"

    async def execute_task(self, prompt: str, subproject_path: Optional[str] = None) -> AsyncGenerator[str, None]:
        """
        Executes a coding/refactoring task using the OpenCode CLI.
        Streams stdout/stderr back line-by-line.
        """
        target_dir = self.workspace_root
        if subproject_path:
            target_dir = os.path.join(self.workspace_root, subproject_path)

        # On Windows, opencode is installed as a npm ps1 script, so running via powershell is robust
        if sys.platform == "win32":
            cmd = f'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "opencode run \"{prompt}\""'
        else:
            cmd = f'opencode run "{prompt}"'

        logger.info(f"Running OpenCode task: {prompt} in {target_dir}")

        try:
            process = await asyncio.create_subprocess_shell(
                cmd,
                cwd=target_dir,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT
            )

            # Read stdout line-by-line
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                yield line.decode(errors="ignore")

            await process.wait()
            if process.returncode != 0:
                logger.error(f"OpenCode task failed with exit code: {process.returncode}")
                yield f"\n[ERROR] OpenCode exited with code {process.returncode}\n"

        except Exception as e:
            logger.error(f"Failed to execute OpenCode command: {str(e)}")
            yield f"\n[ERROR] Execution failed: {str(e)}\n"
