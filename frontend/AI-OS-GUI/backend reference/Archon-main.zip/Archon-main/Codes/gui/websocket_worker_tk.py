import json
import asyncio
import threading
import websockets
import uuid
import queue

class TkWebSocketWorker:
    def __init__(self, url="ws://localhost:8765/ws"):
        self.url = url
        self.loop = None
        self.ws = None
        self.send_queue = None
        self.event_queue = queue.Queue() # Thread-safe queue for Tkinter main thread
        self.running = True
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.send_queue = asyncio.Queue()
        self.loop.run_until_complete(self._connect_and_listen())

    async def _connect_and_listen(self):
        while self.running:
            try:
                async with websockets.connect(self.url) as websocket:
                    self.ws = websocket
                    consumer = asyncio.create_task(self._consume(websocket))
                    producer = asyncio.create_task(self._produce(websocket))
                    await asyncio.gather(consumer, producer)
            except Exception as e:
                self.event_queue.put(("error", "global", f"Connection error: {str(e)}"))
                await asyncio.sleep(2)

    async def _consume(self, websocket):
        async for message in websocket:
            try:
                data = json.loads(message)
                req_id = data.get("id")
                event = data.get("event")
                payload = data.get("payload", {})
                
                if event == "token":
                    text = payload.get("text", "")
                    agent = payload.get("agent", "")
                    self.event_queue.put(("token", req_id, agent, text))
                elif event == "status":
                    status = payload.get("status", "")
                    self.event_queue.put(("status", req_id, status))
                elif event == "gate":
                    self.event_queue.put(("gate", req_id, payload))
                elif event == "done":
                    self.event_queue.put(("done", req_id, payload))
                elif event == "error":
                    err = payload.get("error", "Unknown error")
                    self.event_queue.put(("error", req_id, err))
            except Exception as e:
                self.event_queue.put(("error", "global", f"Error parsing message: {str(e)}"))

    async def _produce(self, websocket):
        while self.running:
            msg = await self.send_queue.get()
            await websocket.send(json.dumps(msg))
            self.send_queue.task_done()

    def send_message(self, mode: str, text: str, attachments: list = None, req_id: str = None) -> str:
        if not req_id:
            req_id = str(uuid.uuid4())
        msg = {
            "id": req_id,
            "mode": mode,
            "type": "send",
            "payload": {
                "text": text,
                "context": {
                    "attachments": attachments or []
                }
            }
        }
        if self.loop and self.send_queue:
            asyncio.run_coroutine_threadsafe(self.send_queue.put(msg), self.loop)
        return req_id

    def send_gate_response(self, req_id: str, action_type: str, payload: dict = None):
        msg = {
            "id": req_id,
            "mode": "",
            "type": action_type,
            "payload": payload or {}
        }
        if self.loop and self.send_queue:
            asyncio.run_coroutine_threadsafe(self.send_queue.put(msg), self.loop)

    def stop(self):
        self.running = False
        if self.loop:
            self.loop.stop()
