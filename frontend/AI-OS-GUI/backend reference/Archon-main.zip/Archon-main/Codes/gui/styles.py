# styles.py - Design system tokens for CustomTkinter (Obsidian & Zinc)

import customtkinter as ctk

# Obsidian & Zinc Color Tokens
C = {
    'bg0':          '#050505',      # True Obsidian - main window background
    'bg1':          '#121214',      # Muted Zinc - elevated panels & sidebar
    'bg2':          '#18181B',      # Hover states & lighter zinc
    'border':       '#27272A',      # Ultra-thin borders
    'text0':        '#E4E4E7',      # Primary reading text (silver/white)
    'text1':        '#A1A1AA',      # Secondary text (charcoal/grey)
    
    # Functional Accents
    'blue':         '#4F46E5',      # Indigo (Chat Mode)
    'amber':        '#F59E0B',      # Warm Gold (Council Mode / Generation)
    'green':        '#10B981',      # Electric Emerald (Agents / Success)
    'violet':       '#8B5CF6',      # Soft Violet (Research / Focus)
}

# Accurate colors to match the mode modes perfectly
MODE_ACCENTS = {
    'chat':     {'primary': C['blue']},
    'council':  {'primary': C['amber']},
    'agents':   {'primary': C['green']},
    'research': {'primary': C['violet']},
}

# Typography Definitions
def get_font_ui(size=13, weight="normal"):
    # Fallback to standard sans-serif if Inter is missing on OS, but requesting it first
    return ("Inter", size, weight)

def get_font_code(size=13, weight="normal"):
    return ("JetBrains Mono", size, weight)