import customtkinter as ctk
import os
import sys

# Ensure components can be imported
sys.path.append(os.path.abspath(os.path.dirname(__file__)))
from components.nav_rail import NavRail
from components.context_sidebar import ContextSidebar
from components.normal_chat import NormalChat
from components.council_debate import CouncilDebate
from components.system_agents import SystemAgents
from components.deep_research import DeepResearch
from components.settings_modal import SettingsModal
from components.confirm_modal import ConfirmModal
from styles import C, get_font_ui, get_font_code

class MainWindow(ctk.CTk):
    def __init__(self, ws_worker):
        super().__init__()
        self.title('The Core — Local AI Operating System')
        self.geometry("1100x750")
        
        self.ws_worker = ws_worker
        self.active_requests = {}
        
        # Poll websocket event queue
        self.after(100, self.poll_websocket)
        
        self.init_ui()
        self.update_system_agents_hotkey("<Control-t>")

    def init_ui(self):
        self.configure(fg_color=C['bg0'])
        
        # Configure Grid: 2 rows, 3 columns
        self.grid_rowconfigure(0, weight=0) # Top Bar (fixed)
        self.grid_rowconfigure(1, weight=1) # Main Area (expanding)
        self.grid_columnconfigure(0, weight=0) # Nav Rail (fixed)
        self.grid_columnconfigure(1, weight=0) # Context Sidebar (fixed)
        self.grid_columnconfigure(2, weight=1) # Workspace (expanding)

        # 1. Nav Rail (Spans both rows)
        self.nav_rail = NavRail(self, command=self.switch_mode)
        self.nav_rail.grid(row=0, column=0, rowspan=2, sticky="nsew")

        # 2. The System Top Bar
        self.top_bar = ctk.CTkFrame(self, fg_color=C['bg0'], corner_radius=0, height=48)
        self.top_bar.grid(row=0, column=1, columnspan=2, sticky="ew")
        
        # Top Bar Bottom Border (1px)
        border_line = ctk.CTkFrame(self.top_bar, height=1, fg_color=C['border'], corner_radius=0)
        border_line.place(relx=0, rely=1.0, anchor="sw", relwidth=1.0)
        
        # Top Bar Content
        branding = ctk.CTkLabel(self.top_bar, text="THE CORE", text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14, "bold")))
        branding.pack(side="left", padx=20, pady=12)

        self.autopilot_switch = ctk.CTkSwitch(self.top_bar, text="AUTOPILOT", progress_color=C['green'], font=ctk.CTkFont(*get_font_ui(12, "bold")))
        self.autopilot_switch.pack(side="left", padx=40, pady=12)

        telemetry = ctk.CTkLabel(self.top_bar, text="CPU: 14% | GPU: 42% | RAM: 8.2GB | LOCAL_HOST: ACTIVE", 
                                 text_color=C['text1'], font=ctk.CTkFont(*get_font_code(10)))
        telemetry.pack(side="right", padx=20, pady=12)

        # 3. Context Sidebar
        self.context_sidebar = ContextSidebar(self)
        self.context_sidebar.grid(row=1, column=1, sticky="nsew")

        # 4. Workspace
        self.workspace_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.workspace_frame.grid(row=1, column=2, sticky="nsew")
        self.workspace_frame.grid_rowconfigure(0, weight=1)
        self.workspace_frame.grid_columnconfigure(0, weight=1)

        # Initialize Mode Panels
        self.mode_panels = {
            'chat': NormalChat(self.workspace_frame, self.ws_worker, self),
            'council': CouncilDebate(self.workspace_frame, self.ws_worker, self),
            'agents': SystemAgents(self.workspace_frame, self.ws_worker, self),
            'research': DeepResearch(self.workspace_frame, self.ws_worker, self)
        }
        
        # Initially display chat
        self.current_panel = None
        self.switch_mode("chat")

    def switch_mode(self, mode_key: str):
        if self.current_panel:
            self.current_panel.grid_forget()
            
        panel = self.mode_panels.get(mode_key)
        if panel:
            panel.grid(row=0, column=0, sticky="nsew")
            self.current_panel = panel
            
        # Update context sidebar visibility based on mode
        self.context_sidebar.grid(row=1, column=1, sticky="nsew")

    def update_system_agents_hotkey(self, hotkey: str):
        try:
            if hasattr(self, "current_agents_hotkey"):
                self.unbind(self.current_agents_hotkey)
            self.current_agents_hotkey = hotkey
            self.bind(hotkey, self.on_system_agents_hotkey)
        except Exception as e:
            print(f"Failed to bind hotkey: {e}")

    def on_system_agents_hotkey(self, event=None):
        if self.current_panel != self.mode_panels['agents']:
            self.nav_rail.on_click('agents')
        else:
            self.mode_panels['agents'].switch_view()

    def register_request(self, req_id: str, mode: str):
        self.active_requests[req_id] = mode

    def poll_websocket(self):
        # Process all pending events from the worker thread
        while not self.ws_worker.event_queue.empty():
            msg = self.ws_worker.event_queue.get_nowait()
            event = msg[0]
            
            if event == "token":
                req_id, agent, text = msg[1], msg[2], msg[3]
                self.on_token_received(req_id, agent, text)
            elif event == "status":
                req_id, status = msg[1], msg[2]
                self.on_status_received(req_id, status)
            elif event == "gate":
                req_id, payload = msg[1], msg[2]
                self.on_gate_received(req_id, payload)
            elif event == "done":
                req_id, payload = msg[1], msg[2]
                self.on_done_received(req_id, payload)
            elif event == "error":
                req_id, err = msg[1], msg[2]
                self.on_error_received(req_id, err)
                
            self.ws_worker.event_queue.task_done()
            
        # Reschedule polling
        self.after(50, self.poll_websocket)

    def on_token_received(self, req_id: str, agent: str, text: str):
        mode = self.active_requests.get(req_id)
        if mode == "chat":
            self.mode_panels['chat'].append_token(text)
        elif mode == "council":
            self.mode_panels['council'].append_token(agent, text)
        elif mode == "research":
            self.mode_panels['research'].append_token(text)
        elif mode == "agent":
            self.mode_panels['agents'].append_token(agent, text)

    def on_status_received(self, req_id: str, status: str):
        mode = self.active_requests.get(req_id)
        if mode == "research":
            self.mode_panels['research'].set_status(status)
        elif mode == "agent":
            self.mode_panels['agents'].set_status(status)

    def on_gate_received(self, req_id: str, payload: dict):
        modal = ConfirmModal(self, payload=payload)
        self.wait_window(modal)
        if modal.result:
            self.ws_worker.send_gate_response(req_id, "confirm", {"approved_urls": payload.get("urls", [])})
        else:
            self.ws_worker.send_gate_response(req_id, "cancel")

    def on_done_received(self, req_id: str, payload: dict):
        mode = self.active_requests.pop(req_id, None)
        if mode == "research":
            self.mode_panels['research'].set_status("Idle - Research completed.")
        elif mode == "agent":
            self.mode_panels['agents'].set_status("Idle - Execution completed.")

    def on_error_received(self, req_id: str, error_msg: str):
        mode = self.active_requests.pop(req_id, None)
        if mode == "chat":
            self.mode_panels['chat'].append_token(f"\n[Error: {error_msg}]\n")
        elif mode == "council":
            self.mode_panels['council'].append_token("System", f"\n[Error: {error_msg}]\n")
        elif mode == "research":
            self.mode_panels['research'].append_token(f"\n[Error: {error_msg}]\n")
        elif mode == "agent":
            self.mode_panels['agents'].append_token("System", f"\n[Error: {error_msg}]\n")

    def destroy(self):
        self.ws_worker.stop()
        super().destroy()