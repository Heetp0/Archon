import customtkinter as ctk
from styles import C, get_font_ui, get_font_code

class NormalChat(ctk.CTkFrame):
    def __init__(self, master, ws_worker, main_window, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.ws_worker = ws_worker
        self.main_window = main_window
        self.current_req_id = None
        
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Center Container (Constrained Width)
        self.center_container = ctk.CTkFrame(self, fg_color="transparent", width=900)
        self.center_container.grid(row=0, column=0, sticky="nsew", padx=40)
        self.center_container.grid_columnconfigure(0, weight=1)
        self.center_container.grid_rowconfigure(1, weight=1)
        
        # Header
        self.header = ctk.CTkLabel(self.center_container, text="The Core: Chat", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['text0'])
        self.header.grid(row=0, column=0, sticky="w", pady=(24, 10))
        
        # Chat History (Obsidian background, Zinc borders)
        self.history = ctk.CTkTextbox(self.center_container, corner_radius=12, fg_color=C['bg0'], 
                                      border_width=1, border_color=C['border'], 
                                      text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        self.history.grid(row=1, column=0, sticky="nsew", pady=10)
        self.history.insert("end", "System initialized. Waiting for input...\n\n")
        self.history.configure(state="disabled")
        
        # Input Frame (The Omnibar)
        self.input_frame = ctk.CTkFrame(self.center_container, fg_color="transparent")
        self.input_frame.grid(row=2, column=0, sticky="ew", pady=(10, 24))
        self.input_frame.grid_columnconfigure(1, weight=1)
        
        # Vault Tag Button
        self.attach_btn = ctk.CTkButton(self.input_frame, text="@", width=42, height=42, corner_radius=21, 
                                        fg_color=C['bg1'], hover_color=C['bg2'], text_color=C['text1'], font=ctk.CTkFont(*get_font_ui(18, "bold")))
        self.attach_btn.grid(row=0, column=0, padx=(0, 10))
        
        # Chat Input
        self.chat_input = ctk.CTkEntry(self.input_frame, height=42, corner_radius=21, 
                                       fg_color=C['bg1'], border_color=C['border'], placeholder_text="Message The Core...",
                                       text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        self.chat_input.grid(row=0, column=1, sticky="ew")
        self.chat_input.bind("<Return>", lambda e: self.send_message())
        
        # Send Button
        self.send_btn = ctk.CTkButton(self.input_frame, text="Send", height=42, corner_radius=21,
                                      fg_color=C['blue'], hover_color=C['bg1'], text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(13, "bold")),
                                      command=self.send_message)
        self.send_btn.grid(row=0, column=2, padx=(10, 0))
        
    def send_message(self):
        text = self.chat_input.get().strip()
        if text:
            self.history.configure(state="normal")
            self.history.insert("end", f"\nYou: {text}\n", "user")
            self.history.insert("end", "The Core: ")
            self.history.configure(state="disabled")
            self.chat_input.delete(0, "end")
            
            if self.ws_worker:
                self.current_req_id = self.ws_worker.send_message("chat", text)
                self.main_window.register_request(self.current_req_id, "chat")
                
    def append_token(self, text: str):
        self.history.configure(state="normal")
        self.history.insert("end", text)
        self.history.see("end")
        self.history.configure(state="disabled")