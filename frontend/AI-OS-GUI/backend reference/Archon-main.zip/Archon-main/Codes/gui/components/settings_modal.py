import customtkinter as ctk
from styles import C, get_font_ui, get_font_code

class SettingsModal(ctk.CTkToplevel):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.title("Settings")
        self.geometry("800x600")
        self.attributes("-topmost", True)
        self.configure(fg_color=C['bg0'])
        
        # Z-index interrupt (blocks interactions with main window)
        self.grab_set()
        self.focus_force()
        
        
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=0, minsize=200) # Menu Sidebar
        self.grid_columnconfigure(1, weight=1)              # Sandbox Content
        
        # Sidebar Menu
        self.sidebar = ctk.CTkFrame(self, fg_color=C['bg1'], corner_radius=0, border_width=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        
        lbl_menu = ctk.CTkLabel(self.sidebar, text="SETTINGS", font=ctk.CTkFont(*get_font_ui(12, "bold")), text_color=C['text1'])
        lbl_menu.pack(pady=(20, 10), padx=20, anchor="w")
        
        self.menu_buttons = {}
        self.content_frames = {}
        
        # Content Area
        self.content_area = ctk.CTkFrame(self, fg_color=C['bg0'], corner_radius=0)
        self.content_area.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.content_area.grid_rowconfigure(0, weight=1)
        self.content_area.grid_columnconfigure(0, weight=1)
        
        # Define Tabs
        self.setup_appearance_tab()
        self.setup_api_keys_tab()
        self.setup_sandbox_tab()
        self.setup_council_tab()
        self.setup_keybindings_tab()
        
        # Create Menu Buttons
        for tab_name in ["Appearance", "API Keys", "Sandbox", "Council", "Keybindings"]:
            btn = ctk.CTkButton(self.sidebar, text=tab_name, fg_color="transparent", hover_color=C['bg2'], 
                                text_color=C['text0'], anchor="w", font=ctk.CTkFont(*get_font_ui(14)),
                                command=lambda n=tab_name: self.show_tab(n))
            btn.pack(fill="x", padx=10, pady=2)
            self.menu_buttons[tab_name] = btn
            
        self.show_tab("Appearance")

    def show_tab(self, name: str):
        for f in self.content_frames.values():
            f.grid_forget()
        self.content_frames[name].grid(row=0, column=0, sticky="nsew")
        
        # Highlight active menu
        for n, btn in self.menu_buttons.items():
            if n == name:
                btn.configure(fg_color=C['bg2'], text_color=C['amber'])
            else:
                btn.configure(fg_color="transparent", text_color=C['text0'])

    def setup_appearance_tab(self):
        f = ctk.CTkFrame(self.content_area, fg_color="transparent")
        self.content_frames["Appearance"] = f
        
        lbl = ctk.CTkLabel(f, text="Appearance", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['amber'])
        lbl.pack(pady=(0, 20), anchor="w")
        
        self.theme_switch = ctk.CTkSwitch(f, text="Dark Mode", progress_color=C['amber'], command=self.toggle_theme, font=ctk.CTkFont(*get_font_ui(14)))
        self.theme_switch.select()
        self.theme_switch.pack(pady=10, anchor="w")
        
    def toggle_theme(self):
        if self.theme_switch.get() == 1:
            ctk.set_appearance_mode("dark")
        else:
            ctk.set_appearance_mode("light")

    def setup_api_keys_tab(self):
        f = ctk.CTkFrame(self.content_area, fg_color="transparent")
        self.content_frames["API Keys"] = f
        f.grid_columnconfigure(1, weight=1)
        
        lbl = ctk.CTkLabel(f, text="API Keys", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['amber'])
        lbl.grid(row=0, column=0, columnspan=3, pady=(0, 20), sticky="w")
        
        keys = ["OpenRouter", "Gemini", "Groq", "Cerebras", "Mistral"]
        for i, key_name in enumerate(keys, start=1):
            lbl_key = ctk.CTkLabel(f, text=key_name, text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
            lbl_key.grid(row=i, column=0, pady=10, sticky="w")
            
            entry = ctk.CTkEntry(f, show="*", fg_color=C['bg1'], border_color=C['border'], text_color=C['text0'])
            entry.grid(row=i, column=1, padx=(20, 20), pady=10, sticky="ew")
            
            btn = ctk.CTkButton(f, text="Save", width=60, fg_color=C['bg2'], hover_color=C['border'], text_color=C['text0'])
            btn.grid(row=i, column=2, pady=10)

    def setup_sandbox_tab(self):
        f = ctk.CTkFrame(self.content_area, fg_color="transparent")
        self.content_frames["Sandbox"] = f
        f.grid_columnconfigure(1, weight=1)
        
        lbl = ctk.CTkLabel(f, text="Sandbox & Constraints", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['amber'])
        lbl.grid(row=0, column=0, columnspan=3, pady=(0, 20), sticky="w")
        
        # Read/Write execution constraints
        self.rw_switch = ctk.CTkSwitch(f, text="Allow File Read/Write Execution", progress_color=C['amber'], font=ctk.CTkFont(*get_font_ui(14)))
        self.rw_switch.grid(row=1, column=0, columnspan=3, pady=10, sticky="w")
        
        self.net_switch = ctk.CTkSwitch(f, text="Allow External Network Access", progress_color=C['amber'], font=ctk.CTkFont(*get_font_ui(14)))
        self.net_switch.grid(row=2, column=0, columnspan=3, pady=10, sticky="w")
        
        def pick_dir(entry_widget):
            path = ctk.filedialog.askdirectory()
            if path:
                entry_widget.delete(0, "end")
                entry_widget.insert(0, path)
                
        lbl_vault = ctk.CTkLabel(f, text="Vault Path", text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        lbl_vault.grid(row=3, column=0, pady=20, sticky="w")
        
        self.entry_vault = ctk.CTkEntry(f, fg_color=C['bg1'], border_color=C['border'], text_color=C['text0'])
        self.entry_vault.grid(row=3, column=1, padx=(20, 20), pady=20, sticky="ew")
        
        btn_vault = ctk.CTkButton(f, text="Browse", width=60, fg_color=C['bg2'], hover_color=C['border'], command=lambda: pick_dir(self.entry_vault))
        btn_vault.grid(row=3, column=2, pady=20)

    def setup_council_tab(self):
        f = ctk.CTkFrame(self.content_area, fg_color="transparent")
        self.content_frames["Council"] = f
        f.grid_columnconfigure(1, weight=1)
        
        lbl = ctk.CTkLabel(f, text="Council Models", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['amber'])
        lbl.grid(row=0, column=0, columnspan=2, pady=(0, 20), sticky="w")
        
        models = ["openrouter: deepseek/deepseek-r1:free", "gemini-2.5-flash", "groq: llama-3.3-70b-versatile"]
        roles = ["Proposer", "Critic", "Domain Expert"]
        for i, role in enumerate(roles, start=1):
            lbl_role = ctk.CTkLabel(f, text=f"{role}", text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
            lbl_role.grid(row=i, column=0, pady=20, sticky="w")
            
            menu = ctk.CTkOptionMenu(f, values=models, fg_color=C['bg1'], button_color=C['bg2'], button_hover_color=C['border'])
            menu.grid(row=i, column=1, padx=20, pady=20, sticky="ew")

    def setup_keybindings_tab(self):
        f = ctk.CTkFrame(self.content_area, fg_color="transparent")
        self.content_frames["Keybindings"] = f
        f.grid_columnconfigure(1, weight=1)
        
        lbl = ctk.CTkLabel(f, text="Keybindings", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['amber'])
        lbl.grid(row=0, column=0, columnspan=3, pady=(0, 20), sticky="w")
        
        lbl_hotkey = ctk.CTkLabel(f, text="Agents Toggle", text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        lbl_hotkey.grid(row=1, column=0, pady=20, sticky="w")
        
        self.hotkey_var = ctk.StringVar(value="<Control-t>")
        self.entry_hotkey = ctk.CTkEntry(f, textvariable=self.hotkey_var, fg_color=C['bg1'], border_color=C['border'], text_color=C['text0'])
        self.entry_hotkey.grid(row=1, column=1, padx=(20, 20), pady=20, sticky="ew")
        
        btn_apply = ctk.CTkButton(f, text="Apply", width=60, fg_color=C['bg2'], hover_color=C['border'], command=self.apply_keybinding)
        btn_apply.grid(row=1, column=2, pady=20)
        
    def apply_keybinding(self):
        new_hotkey = self.hotkey_var.get()
        if hasattr(self.master, "update_system_agents_hotkey"):
            self.master.update_system_agents_hotkey(new_hotkey)