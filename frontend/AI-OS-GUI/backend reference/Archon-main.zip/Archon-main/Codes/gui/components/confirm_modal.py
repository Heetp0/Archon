import customtkinter as ctk

class ConfirmModal(ctk.CTkToplevel):
    def __init__(self, master, payload=None, **kwargs):
        super().__init__(master, **kwargs)
        self.title("Action Required")
        self.geometry("450x250")
        self.attributes("-topmost", True)
        self.grab_set() # Make modal
        
        self.result = False
        
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        frame = ctk.CTkFrame(self)
        frame.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        
        action = payload.get("action", "Unknown action") if payload else "Unknown action"
        desc = payload.get("description", "An agent requested permission to proceed.") if payload else ""
        
        lbl = ctk.CTkLabel(frame, text=f"Permission Requested: {action}", font=ctk.CTkFont(size=16, weight="bold"), text_color="#EF4444")
        lbl.pack(pady=(10, 5))
        
        desc_lbl = ctk.CTkLabel(frame, text=desc, wraplength=380)
        desc_lbl.pack(pady=10)
        
        btn_frame = ctk.CTkFrame(frame, fg_color="transparent")
        btn_frame.pack(pady=20)
        
        cancel_btn = ctk.CTkButton(btn_frame, text="Cancel", fg_color="#3F3F46", hover_color="#52525B", command=self.on_cancel)
        cancel_btn.pack(side="left", padx=10)
        
        confirm_btn = ctk.CTkButton(btn_frame, text="Approve", fg_color="#EF4444", hover_color="#DC2626", command=self.on_confirm)
        confirm_btn.pack(side="left", padx=10)
        
    def on_cancel(self):
        self.result = False
        self.destroy()
        
    def on_confirm(self):
        self.result = True
        self.destroy()
