import customtkinter as ctk
from styles import C, get_font_ui, get_font_code

class CouncilDebate(ctk.CTkFrame):
    def __init__(self, master, ws_worker, main_window, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.ws_worker = ws_worker
        self.main_window = main_window
        self.current_req_id = None
        
        self.grid_rowconfigure(1, weight=2) # Peers (40%)
        self.grid_rowconfigure(2, weight=3) # Synthesizer (60%)
        self.grid_columnconfigure(0, weight=1)
        
        # Header
        self.header_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=24, pady=(24, 10))
        self.header = ctk.CTkLabel(self.header_frame, text="The Council of AI", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['amber'])
        self.header.grid(row=0, column=0, sticky="w")
        
        # Peers Frame
        self.peers_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.peers_frame.grid(row=1, column=0, sticky="nsew", padx=24, pady=(0, 10))
        self.peers_frame.grid_rowconfigure(0, weight=1)
        self.peers_frame.grid_columnconfigure(0, weight=1)
        self.peers_frame.grid_columnconfigure(1, weight=1)
        self.peers_frame.grid_columnconfigure(2, weight=1)
        
        # Agent 1: Proposer
        self.agent1_panel = self._create_agent_panel(self.peers_frame, "Agent 1 (Proposer)", 0)
        # Agent 2: Critic
        self.agent2_panel = self._create_agent_panel(self.peers_frame, "Agent 2 (Critic)", 1)
        # Agent 3: Domain Expert
        self.agent3_panel = self._create_agent_panel(self.peers_frame, "Agent 3 (Domain Expert)", 2)
        
        # Synthesizer Block
        self.synth_frame = ctk.CTkFrame(self, fg_color=C['bg0'], border_width=1, border_color=C['border'], corner_radius=12)
        self.synth_frame.grid(row=2, column=0, sticky="nsew", padx=24, pady=(0, 10))
        self.synth_frame.grid_rowconfigure(1, weight=1)
        self.synth_frame.grid_columnconfigure(0, weight=1)
        
        self.synth_lbl = ctk.CTkLabel(self.synth_frame, text="⚖ Synthesizer — Final Verdict", text_color=C['amber'], font=ctk.CTkFont(*get_font_ui(13, "bold")))
        self.synth_lbl.grid(row=0, column=0, sticky="w", padx=15, pady=(10, 0))
        
        self.synth_text = ctk.CTkTextbox(self.synth_frame, fg_color="transparent", text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        self.synth_text.grid(row=1, column=0, sticky="nsew", padx=10, pady=(5, 10))
        self.synth_text.configure(state="disabled")

        # Input Frame
        self.input_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.input_frame.grid(row=3, column=0, sticky="ew", padx=24, pady=(10, 24))
        self.input_frame.grid_columnconfigure(0, weight=1)
        
        self.chat_input = ctk.CTkEntry(self.input_frame, height=42, corner_radius=21, 
                                       fg_color=C['bg1'], border_color=C['amber'], border_width=1, placeholder_text="Present a topic for debate...",
                                       text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        self.chat_input.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.chat_input.bind("<Return>", lambda e: self.send_message())
        
        self.send_btn = ctk.CTkButton(self.input_frame, text="Deliberate", height=42, corner_radius=21,
                                      fg_color=C['amber'], hover_color=C['bg2'], text_color=C['bg0'], font=ctk.CTkFont(*get_font_ui(13, "bold")),
                                      command=self.send_message)
        self.send_btn.grid(row=0, column=1)

    def _create_agent_panel(self, parent, title, col):
        frame = ctk.CTkFrame(parent, fg_color=C['bg1'], border_width=1, border_color=C['border'], corner_radius=12)
        frame.grid(row=0, column=col, sticky="nsew", padx=5)
        frame.grid_rowconfigure(1, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        
        lbl = ctk.CTkLabel(frame, text=title, font=ctk.CTkFont(*get_font_ui(13, "bold")), text_color=C['text0'])
        lbl.grid(row=0, column=0, pady=(10, 0))
        
        textbox = ctk.CTkTextbox(frame, fg_color="transparent", text_color=C['text1'], wrap="word", font=ctk.CTkFont(*get_font_code(12)))
        textbox.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        textbox.configure(state="disabled")
        return textbox

    def send_message(self):
        text = self.chat_input.get().strip()
        if text:
            for tb in [self.agent1_panel, self.agent2_panel, self.agent3_panel, self.synth_text]:
                tb.configure(state="normal")
                tb.delete("1.0", "end")
                tb.configure(state="disabled")
            
            self.agent1_panel.configure(state="normal")
            self.agent1_panel.insert("end", f"Debating: {text}\n\n")
            self.agent1_panel.configure(state="disabled")
            
            self.chat_input.delete(0, "end")
            
            if self.ws_worker:
                self.current_req_id = self.ws_worker.send_message("council", text)
                self.main_window.register_request(self.current_req_id, "council")

    def append_token(self, agent: str, text: str):
        target = None
        if "proposer" in agent.lower() or "agent1" in agent.lower():
            target = self.agent1_panel
        elif "critic" in agent.lower() or "agent2" in agent.lower():
            target = self.agent2_panel
        elif "domain" in agent.lower() or "expert" in agent.lower() or "agent3" in agent.lower():
            target = self.agent3_panel
        elif "synth" in agent.lower() or "verdict" in agent.lower():
            target = self.synth_text
        
        if target:
            target.configure(state="normal")
            target.insert("end", text)
            target.see("end")
            target.configure(state="disabled")