import customtkinter as ctk
from styles import C, get_font_ui, get_font_code

class DeepResearch(ctk.CTkFrame):
    def __init__(self, master, ws_worker, main_window, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.ws_worker = ws_worker
        self.main_window = main_window
        self.current_req_id = None
        
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Header
        self.header_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=24, pady=(24, 10))
        self.header_frame.grid_columnconfigure(1, weight=1)
        
        self.header = ctk.CTkLabel(self.header_frame, text="Deep Research", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['blue'])
        self.header.grid(row=0, column=0, sticky="w")
        
        self.status_lbl = ctk.CTkLabel(self.header_frame, text="Idle", text_color=C['text1'], font=ctk.CTkFont(*get_font_ui(12)))
        self.status_lbl.grid(row=0, column=2, sticky="e")
        
        # Workspace Canvas
        self.workspace_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.workspace_frame.grid(row=1, column=0, sticky="nsew", padx=24, pady=10)
        self.workspace_frame.grid_rowconfigure(0, weight=1)
        self.workspace_frame.grid_columnconfigure(0, weight=1) # Ledger
        self.workspace_frame.grid_columnconfigure(1, weight=3) # Graph
        self.workspace_frame.grid_columnconfigure(2, weight=1) # Chat
        
        # 1. Source Ledger (Left)
        self.ledger_frame = ctk.CTkFrame(self.workspace_frame, fg_color=C['bg1'], border_width=1, border_color=C['border'], corner_radius=12)
        self.ledger_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        lbl_ledger = ctk.CTkLabel(self.ledger_frame, text="Source Ledger", font=ctk.CTkFont(*get_font_ui(14, "bold")), text_color=C['blue'])
        lbl_ledger.grid(row=0, column=0, pady=15, padx=15, sticky="w")
        
        # 2. Knowledge Graph (Center)
        self.graph_frame = ctk.CTkFrame(self.workspace_frame, fg_color=C['bg0'], border_width=1, border_color=C['border'], corner_radius=12)
        self.graph_frame.grid(row=0, column=1, sticky="nsew", padx=10)
        self.graph_frame.grid_rowconfigure(0, weight=1)
        self.graph_frame.grid_columnconfigure(0, weight=1)
        
        self.canvas = ctk.CTkCanvas(self.graph_frame, bg=C['bg0'], highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        self.canvas.bind("<Configure>", lambda e: self._draw_placeholder_graph())
        
        # 3. Grounded Chat (Right)
        self.chat_frame = ctk.CTkFrame(self.workspace_frame, fg_color=C['bg1'], border_width=1, border_color=C['border'], corner_radius=12)
        self.chat_frame.grid(row=0, column=2, sticky="nsew", padx=(10, 0))
        self.chat_frame.grid_rowconfigure(1, weight=1)
        self.chat_frame.grid_columnconfigure(0, weight=1)
        
        lbl_chat = ctk.CTkLabel(self.chat_frame, text="Grounded Chat", font=ctk.CTkFont(*get_font_ui(14, "bold")), text_color=C['blue'])
        lbl_chat.grid(row=0, column=0, pady=15, padx=15, sticky="w")
        
        self.report_text = ctk.CTkTextbox(self.chat_frame, fg_color="transparent", text_color=C['text0'], wrap="word", font=ctk.CTkFont(*get_font_ui(13)))
        self.report_text.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        self.report_text.insert("1.0", "No report generated yet.")
        self.report_text.configure(state="disabled")

        # Input Frame
        self.input_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.input_frame.grid(row=2, column=0, sticky="ew", padx=24, pady=(10, 24))
        self.input_frame.grid_columnconfigure(0, weight=1)
        
        self.chat_input = ctk.CTkEntry(self.input_frame, height=42, corner_radius=21, 
                                       fg_color=C['bg1'], border_color=C['blue'], border_width=1, placeholder_text="Enter a topic for deep research...",
                                       text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        self.chat_input.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.chat_input.bind("<Return>", lambda e: self.send_message())
        
        self.send_btn = ctk.CTkButton(self.input_frame, text="Initialize", height=42, corner_radius=21,
                                      fg_color=C['blue'], hover_color=C['bg2'], text_color=C['bg0'], font=ctk.CTkFont(*get_font_ui(13, "bold")),
                                      command=self.send_message)
        self.send_btn.grid(row=0, column=1)

    def _draw_placeholder_graph(self):
        self.canvas.delete("all")
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w <= 1 or h <= 1:
            return
            
        cx, cy = w/2, h/2
        # Center node
        self.canvas.create_oval(cx-20, cy-20, cx+20, cy+20, fill=C['blue'], outline="")
        
        # Satellite nodes
        self.canvas.create_line(cx, cy, cx-150, cy-150, fill=C['border'], dash=(4, 4))
        self.canvas.create_oval(cx-170, cy-170, cx-130, cy-130, fill=C['bg1'], outline=C['blue'])
        
        self.canvas.create_line(cx, cy, cx+150, cy-120, fill=C['border'], dash=(4, 4))
        self.canvas.create_oval(cx+130, cy-140, cx+170, cy-100, fill=C['bg1'], outline=C['blue'])
        
        self.canvas.create_line(cx, cy, cx-100, cy+150, fill=C['border'], dash=(4, 4))
        self.canvas.create_oval(cx-120, cy+130, cx-80, cy+170, fill=C['bg1'], outline=C['blue'])

    def send_message(self):
        text = self.chat_input.get().strip()
        if text:
            self.report_text.configure(state="normal")
            self.report_text.delete("1.0", "end")
            self.report_text.insert("end", f"Researching: {text}\n\n")
            self.report_text.configure(state="disabled")
            
            self.chat_input.delete(0, "end")
            self.set_status("Initializing...")
            
            if self.ws_worker:
                self.current_req_id = self.ws_worker.send_message("research", text)
                self.main_window.register_request(self.current_req_id, "research")

    def append_token(self, text: str):
        self.report_text.configure(state="normal")
        self.report_text.insert("end", text)
        self.report_text.see("end")
        self.report_text.configure(state="disabled")
        
    def set_status(self, status: str):
        self.status_lbl.configure(text=status)