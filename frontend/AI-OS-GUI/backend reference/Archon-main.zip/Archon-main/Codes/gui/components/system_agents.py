import customtkinter as ctk
from styles import C, get_font_ui, get_font_code

class SystemAgents(ctk.CTkFrame):
    def __init__(self, master, ws_worker, main_window, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.ws_worker = ws_worker
        self.main_window = main_window
        self.current_req_id = None
        
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Header area
        self.header_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=24, pady=(24, 10))
        self.header_frame.grid_columnconfigure(1, weight=1)
        
        self.header = ctk.CTkLabel(self.header_frame, text="System Agents", font=ctk.CTkFont(*get_font_ui(24, "bold")), text_color=C['green'])
        self.header.grid(row=0, column=0, sticky="w")
        
        # Segmented Toggle
        self.current_view = "dashboard"
        self.toggle = ctk.CTkSegmentedButton(self.header_frame, values=["Dashboard", "Terminal"], command=self.switch_view,
                                             selected_color=C['bg2'], unselected_color=C['bg1'], 
                                             selected_hover_color=C['border'], font=ctk.CTkFont(*get_font_ui(12, "bold")))
        self.toggle.set("Dashboard")
        self.toggle.grid(row=0, column=2, sticky="e")
        
        self.shortcut_hint = ctk.CTkLabel(self.header_frame, text="(Ctrl+T to switch)", text_color=C['text1'], font=ctk.CTkFont(*get_font_ui(12)))
        self.shortcut_hint.grid(row=0, column=3, sticky="w", padx=(10, 0))
        
        # View Container (both frames in same cell)
        self.view_container = ctk.CTkFrame(self, fg_color="transparent")
        self.view_container.grid(row=1, column=0, sticky="nsew", padx=24, pady=10)
        self.view_container.grid_rowconfigure(0, weight=1)
        self.view_container.grid_columnconfigure(0, weight=1)
        
        # Frame A: Dashboard
        self.frame_dashboard = ctk.CTkFrame(self.view_container, fg_color=C['bg1'], corner_radius=12, border_width=1, border_color=C['border'])
        self.frame_dashboard.grid(row=0, column=0, sticky="nsew")
        self.frame_dashboard.grid_rowconfigure(2, weight=1)
        self.frame_dashboard.grid_columnconfigure(0, weight=1)
        
        lbl_status = ctk.CTkLabel(self.frame_dashboard, text="Active Task Checklist", font=ctk.CTkFont(*get_font_ui(14, "bold")), text_color=C['text0'])
        lbl_status.grid(row=0, column=0, pady=(20, 5), padx=20, sticky="w")
        
        self.status_text = ctk.CTkLabel(self.frame_dashboard, text="[Idle] No active system subagents.", text_color=C['text1'], font=ctk.CTkFont(*get_font_ui(13)))
        self.status_text.grid(row=1, column=0, sticky="w", padx=20)
        
        # Dashboard Checklist Card Example
        self.checklist_frame = ctk.CTkFrame(self.frame_dashboard, fg_color=C['bg2'], corner_radius=8)
        self.checklist_frame.grid(row=2, column=0, sticky="nw", padx=20, pady=10, ipadx=10, ipady=10)
        
        dot = ctk.CTkLabel(self.checklist_frame, text="🟢", font=ctk.CTkFont(size=10))
        dot.grid(row=0, column=0, padx=(10, 5))
        task_lbl = ctk.CTkLabel(self.checklist_frame, text="Agent 01: Ready", text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(13, "bold")))
        task_lbl.grid(row=0, column=1, sticky="w")
        
        # Frame B: Terminal
        self.frame_terminal = ctk.CTkFrame(self.view_container, fg_color=C['bg0'], corner_radius=12, border_width=1, border_color=C['border'])
        self.frame_terminal.grid(row=0, column=0, sticky="nsew")
        self.frame_terminal.grid_rowconfigure(0, weight=1)
        self.frame_terminal.grid_columnconfigure(0, weight=1)
        
        self.term_output = ctk.CTkTextbox(self.frame_terminal, fg_color="transparent", text_color=C['green'], font=ctk.CTkFont(*get_font_code(13)))
        self.term_output.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.term_output.insert("end", "$ core@local:~$ System initialized...\n")
        self.term_output.configure(state="disabled")
        
        # Input Frame
        self.input_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.input_frame.grid(row=2, column=0, sticky="ew", padx=24, pady=(10, 24))
        self.input_frame.grid_columnconfigure(0, weight=1)
        
        # Command Input
        self.cmd_input = ctk.CTkEntry(self.input_frame, height=42, corner_radius=21, 
                                       fg_color=C['bg1'], border_color=C['green'], border_width=1, placeholder_text="Enter a system command or task...",
                                       text_color=C['text0'], font=ctk.CTkFont(*get_font_ui(14)))
        self.cmd_input.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.cmd_input.bind("<Return>", lambda e: self.send_command())
        
        # Execute Button
        self.exec_btn = ctk.CTkButton(self.input_frame, text="Execute", height=42, corner_radius=21,
                                      fg_color=C['green'], hover_color=C['bg1'], text_color=C['bg0'], font=ctk.CTkFont(*get_font_ui(13, "bold")),
                                      command=self.send_command)
        self.exec_btn.grid(row=0, column=1)

        # Show Dashboard initially
        self.frame_dashboard.tkraise()

    def switch_view(self, value=None):
        if value:
            self.current_view = value.lower()
        else:
            self.current_view = "terminal" if self.current_view == "dashboard" else "dashboard"
            self.toggle.set(self.current_view.capitalize())
            
        if self.current_view == "dashboard":
            self.frame_dashboard.tkraise()
        else:
            self.frame_terminal.tkraise()

    def set_status(self, status: str):
        self.status_text.configure(text=status)
        
    def send_command(self):
        text = self.cmd_input.get().strip()
        if text:
            self.term_output.configure(state="normal")
            self.term_output.insert("end", f"$ core@local:~$ {text}\n", "cmd")
            self.term_output.see("end")
            self.term_output.configure(state="disabled")
            self.cmd_input.delete(0, "end")
            self.set_status("Executing...")
            
            if self.ws_worker:
                self.current_req_id = self.ws_worker.send_message("agent", text)
                self.main_window.register_request(self.current_req_id, "agent")

    def append_token(self, agent: str, text: str):
        self.term_output.configure(state="normal")
        if agent:
            self.term_output.insert("end", f"[{agent}] ")
        self.term_output.insert("end", text)
        self.term_output.see("end")
        self.term_output.configure(state="disabled")