import os
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QPushButton, QTreeWidget, QTreeWidgetItem, QFrame)
from PySide6.QtCore import Qt, Signal
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from styles import C, MODE_ACCENTS

class SidebarTabButton(QPushButton):
    def __init__(self, label: str, mode_key: str, parent=None):
        super().__init__(label, parent)
        self.mode_key = mode_key
        self.accent = MODE_ACCENTS[mode_key]['primary']
        self.setCheckable(True)
        self.setFixedHeight(42)
        self.setCursor(Qt.PointingHandCursor)
        self.update_style(False)

    def update_style(self, active: bool):
        if active:
            # High-end active state with left vertical accent bar and fading gradient glow
            self.setStyleSheet(f"""
                QPushButton {{
                    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {MODE_ACCENTS[self.mode_key]['glow']}, stop:1 transparent);
                    color: {self.accent};
                    border-left: 4px solid {self.accent};
                    border-right: none; border-top: none; border-bottom: none;
                    border-radius: 0px;
                    padding-left: 18px;
                    font-weight: 800;
                    text-align: left;
                    font-size: 13px;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QPushButton {{
                    background-color: transparent;
                    color: {C['text1']};
                    border: none;
                    border-radius: 0px;
                    padding-left: 22px;
                    text-align: left;
                    font-size: 13px;
                }}
                QPushButton:hover {{
                    background-color: rgba(255, 255, 255, 0.03);
                    color: {C['text0']};
                }}
            """)

class Sidebar(QWidget):
    mode_changed = Signal(str)
    settings_clicked = Signal()
    help_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {C['bg1']};
                border-right: 1px solid {C['border0']};
            }}
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 24, 0, 20)
        layout.setSpacing(8)

        # Header Title with a modern, sleek tech aesthetic
        self.header_label = QLabel('THE CORE', self)
        self.header_label.setStyleSheet(f"""
            QLabel {{
                color: {C['text0']};
                font-size: 17px;
                font-weight: 900;
                letter-spacing: 3px;
                padding-left: 24px;
                margin-bottom: 20px;
            }}
        """)
        layout.addWidget(self.header_label)

        self.buttons = {}
        tab_configs = [
            ('Normal Chat', 'chat'),
            ('The Council', 'council'),
            ('System Agents', 'agents'),
            ('Deep Research', 'research')
        ]
        
        for label, key in tab_configs:
            btn = SidebarTabButton(label, key, self)
            btn.clicked.connect(lambda checked=False, k=key: self.select_tab(k))
            layout.addWidget(btn)
            self.buttons[key] = btn

        # Modern minimalist divider line
        divider = QFrame(self)
        divider.setFrameShape(QFrame.HLine)
        divider.setStyleSheet(f"background-color: {C['border0']}; margin: 15px 20px;")
        layout.addWidget(divider)

        # Vault Section header
        vault_title = QLabel('THE VAULT', self)
        vault_title.setStyleSheet(f"""
            QLabel {{
                color: {C['text2']};
                font-size: 11px;
                font-weight: 800;
                letter-spacing: 2px;
                padding-left: 24px;
                margin-bottom: 5px;
            }}
        """)
        layout.addWidget(vault_title)

        # Interactive document tree view
        self.tree = QTreeWidget(self)
        self.tree.setHeaderHidden(True)
        self.tree.setStyleSheet(f"""
            QTreeWidget {{
                background-color: transparent;
                border: none;
                margin-left: 12px;
            }}
            QTreeWidget::item {{
                padding-left: 8px;
            }}
        """)
        self.populate_dummy_vault()
        layout.addWidget(self.tree)

        # Settings and Help footer buttons
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(20, 10, 20, 0)
        bottom_layout.setSpacing(10)
        
        self.help_btn = QPushButton('Help', self)
        self.help_btn.setCursor(Qt.PointingHandCursor)
        self.help_btn.setFixedHeight(34)
        self.help_btn.clicked.connect(self.help_clicked.emit)
        self.help_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {C['bg2']};
                border: 1px solid {C['border0']};
                border-radius: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background-color: {C['bg3']};
            }}
        """)
        
        self.settings_btn = QPushButton('Settings', self)
        self.settings_btn.setCursor(Qt.PointingHandCursor)
        self.settings_btn.setFixedHeight(34)
        self.settings_btn.clicked.connect(self.settings_clicked.emit)
        self.settings_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {C['bg2']};
                border: 1px solid {C['border0']};
                border-radius: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background-color: {C['bg3']};
            }}
        """)

        bottom_layout.addWidget(self.help_btn)
        bottom_layout.addWidget(self.settings_btn)
        layout.addLayout(bottom_layout)

        self.select_tab('chat')

    def select_tab(self, active_key: str):
        for key, btn in self.buttons.items():
            btn.update_style(key == active_key)
        self.mode_changed.emit(active_key)

    def populate_dummy_vault(self):
        wiki = QTreeWidgetItem(self.tree, ['📂 SecondBrain'])
        notes = QTreeWidgetItem(self.tree, ['📂 AI Notes'])
        
        wiki.addChild(QTreeWidgetItem(['📄 System Design.md']))
        wiki.addChild(QTreeWidgetItem(['📄 Life Goals.md']))
        notes.addChild(QTreeWidgetItem(['📄 Model Benchmarks.md']))
        notes.addChild(QTreeWidgetItem(['📄 API Credentials.md']))
        
        self.tree.expandAll()