import customtkinter as ctk
import tkinter as tk
from tkinter import ttk
import os
from styles import C, get_font_ui

class ContextSidebar(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, width=240, corner_radius=0, fg_color=C['bg1'], **kwargs)
        
        self.grid_rowconfigure(1, weight=3) # Vault Tree
        self.grid_rowconfigure(3, weight=2) # Recent Sessions
        self.grid_columnconfigure(0, weight=1)
        
        # Pill Switcher (The Vault vs History)
        self.switcher = ctk.CTkSegmentedButton(self, values=["The Vault", "History"], 
                                               selected_color=C['bg2'], unselected_color=C['bg1'], 
                                               selected_hover_color=C['border'], font=ctk.CTkFont(*get_font_ui(12, "bold")))
        self.switcher.set("The Vault")
        self.switcher.grid(row=0, column=0, sticky="ew", padx=15, pady=(15, 5))
        
        # Style Treeview
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", 
                        background=C['bg1'], 
                        foreground=C['text0'], 
                        fieldbackground=C['bg1'], 
                        borderwidth=0, 
                        font=get_font_ui(11))
        style.configure("Treeview.Heading", 
                        background=C['bg1'], 
                        foreground=C['text1'], 
                        borderwidth=0, 
                        font=get_font_ui(11, "bold"))
        style.map("Treeview", background=[('selected', C['bg2'])])
        
        # Treeview
        self.tree = ttk.Treeview(self, show="tree")
        self.tree.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        
        # Scrollbar
        self.scrollbar = ctk.CTkScrollbar(self, command=self.tree.yview)
        self.scrollbar.grid(row=1, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=self.scrollbar.set)
        
        # Load sample data
        self.populate_vault()
        
        # Remove old RECENT SESSIONS Header, as it's part of the segmented switcher now
        # We will just show the recent frame below the tree for now (or switch visibility later)
        
        # Recent Sessions List
        self.recent_frame = ctk.CTkScrollableFrame(self, fg_color="transparent", bg_color="transparent")
        self.recent_frame.grid(row=3, column=0, columnspan=2, sticky="nsew", padx=5, pady=(0, 10))
        
        self.populate_recent_sessions()
        
    def populate_recent_sessions(self):
        sessions = [
            "Session 2026-06-28",
            "Session 2026-06-27",
            "Session 2026-06-26",
            "Architecture Review",
            "Debugging Session"
        ]
        for session in sessions:
            btn = ctk.CTkButton(self.recent_frame, text=session, fg_color="transparent", 
                                text_color=C['text0'], hover_color=C['bg2'], anchor="w",
                                font=ctk.CTkFont(*get_font_ui(11)))
            btn.pack(fill="x", pady=2, padx=5)
        
    def populate_vault(self):
        vault_root = self.tree.insert("", "end", text="SecondBrain", open=True)
        wiki = self.tree.insert(vault_root, "end", text="Wiki", open=True)
        self.tree.insert(wiki, "end", text="architecture.md")
        self.tree.insert(wiki, "end", text="guidelines.md")
        
        notes = self.tree.insert(vault_root, "end", text="AI Notes", open=True)
        self.tree.insert(notes, "end", text="session_logs.md")
        self.tree.insert(notes, "end", text="research_summary.md")
