import customtkinter as ctk
from styles import C, get_font_ui

class NavRail(ctk.CTkFrame):
    def __init__(self, master, command=None, **kwargs):
        super().__init__(master, width=64, corner_radius=0, fg_color=C['bg1'], **kwargs)
        
        self.command = command
        
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(5, weight=1) # Spacer
        
        self.btn_chat = ctk.CTkButton(self, text="💬", width=44, height=44, fg_color="transparent", hover_color=C['bg2'],
                                      font=ctk.CTkFont(size=24), command=lambda: self.on_click("chat"))
        self.btn_chat.grid(row=0, column=0, pady=10, padx=10)
        
        self.btn_council = ctk.CTkButton(self, text="🏛️", width=44, height=44, fg_color="transparent", hover_color=C['bg2'],
                                         font=ctk.CTkFont(size=24), command=lambda: self.on_click("council"))
        self.btn_council.grid(row=1, column=0, pady=10, padx=10)
        
        self.btn_agents = ctk.CTkButton(self, text="🤖", width=44, height=44, fg_color="transparent", hover_color=C['bg2'],
                                        font=ctk.CTkFont(size=24), command=lambda: self.on_click("agents"))
        self.btn_agents.grid(row=2, column=0, pady=10, padx=10)
        
        self.btn_research = ctk.CTkButton(self, text="🕸️", width=44, height=44, fg_color="transparent", hover_color=C['bg2'],
                                          font=ctk.CTkFont(size=24), command=lambda: self.on_click("research"))
        self.btn_research.grid(row=3, column=0, pady=10, padx=10)
        
        self.btn_settings = ctk.CTkButton(self, text="⚙️", width=44, height=44, fg_color="transparent", hover_color=C['bg2'],
                                          font=ctk.CTkFont(size=24), command=lambda: self.on_click("settings"))
        self.btn_settings.grid(row=6, column=0, pady=10, padx=10)
        
    def on_click(self, mode_key: str):
        if mode_key == "settings":
            from components.settings_modal import SettingsModal
            SettingsModal(self.winfo_toplevel())
        else:
            if self.command:
                self.command(mode_key)
