import sys
import os
import threading
import time
import uvicorn
import customtkinter as ctk

# Setup path resolution for both gui and daemon modules
gui_dir = os.path.abspath(os.path.dirname(__file__))
project_root = os.path.abspath(os.path.join(gui_dir, "..", ".."))
daemon_dir = os.path.join(project_root, "daemon")

sys.path.insert(0, gui_dir)
sys.path.insert(0, daemon_dir)

from main_window import MainWindow
from websocket_worker_tk import TkWebSocketWorker
from styles import C, get_font_ui

class SplashScreen(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Archon Loader")
        
        # Make borderless and stays on top
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        
        # Center splash on screen
        width, height = 500, 320
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.configure(fg_color=C['bg0'])

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Gradient line at the top
        accent_bar = ctk.CTkFrame(self, height=5, fg_color=C['violet'], corner_radius=0)
        accent_bar.grid(row=0, column=0, sticky="ew")

        # Title Label
        title_lbl = ctk.CTkLabel(self, text="THE CORE", text_color=C['text0'],
                                 font=ctk.CTkFont(*get_font_ui(32, "bold")))
        title_lbl.grid(row=1, column=0, sticky="w", padx=40, pady=(40, 5))

        # Subtitle Label
        sub_lbl = ctk.CTkLabel(self, text="Personal AI Command Center & OS", text_color=C['text1'],
                               font=ctk.CTkFont(*get_font_ui(13)))
        sub_lbl.grid(row=2, column=0, sticky="nw", padx=40, pady=0)

        # Status Label
        self.status_lbl = ctk.CTkLabel(self, text="Initializing background daemon...", text_color=C['text1'],
                                       font=ctk.CTkFont(*get_font_ui(11)))
        self.status_lbl.grid(row=3, column=0, sticky="sw", padx=40, pady=(0, 10))

        # Progress Bar
        self.progress = ctk.CTkProgressBar(self, width=420, height=6, corner_radius=3, progress_color=C['violet'])
        self.progress.grid(row=4, column=0, sticky="ew", padx=40, pady=(0, 30))
        self.progress.set(0.0)

        # Start loading sequence
        self.after(200, self.start_initialization)

    def set_status(self, text: str):
        self.status_lbl.configure(text=text)
        self.update()

    def start_initialization(self):
        self.progress.set(0.25)
        # 1. Start the FastAPI daemon sidecar in a background thread
        from main import app as fastapi_app
        
        def run_backend():
            uvicorn.run(fastapi_app, host="127.0.0.1", port=8765, log_level="warning")
            
        self.set_status("Starting FastAPI background services...")
        daemon_thread = threading.Thread(target=run_backend, daemon=True)
        daemon_thread.start()

        # 2. Wait a brief moment for FastAPI to spin up
        self.set_status("Loading vector database and knowledge vault...")
        self.progress.set(0.50)
        self.after(800, self.connect_websocket)

    def connect_websocket(self):
        # 3. Spin up the WebSocket worker client
        self.set_status("Establishing real-time WebSocket connection...")
        self.progress.set(0.75)
        try:
            ws_worker = TkWebSocketWorker("ws://127.0.0.1:8765/ws")
        except Exception as e:
            print(f"WebSocket connect error: {e}")
            ws_worker = None

        # 4. Instantiate MainWindow
        self.set_status("Constructing workspace grid views...")
        self.progress.set(0.90)
        self.after(500, lambda: self.launch_main_window(ws_worker))

    def launch_main_window(self, ws_worker):
        self.progress.set(1.0)
        self.update()
        # Close splash and open main window
        self.destroy()
        
        window = MainWindow(ws_worker)
        window.mainloop()

def main():
    # Set appearance mode to dark
    ctk.set_appearance_mode("dark")
    
    splash = SplashScreen()
    splash.mainloop()

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    main()
